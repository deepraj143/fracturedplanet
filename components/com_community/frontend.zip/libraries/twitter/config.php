<?php

/**
 * @file
 * A single location to store configuration.
 */
define('CONSUMER_KEY', 'Zmiv8dlZam5iyOPA6BurA');
define('CONSUMER_SECRET', 'sVfismquJwlckz1oJSTNHhfSitGHtgk9dkp4m1fZbQ');